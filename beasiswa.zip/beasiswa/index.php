<?php
session_start();
require_once "config.php";
if (!isset($_SESSION["is_logged"])) {
    header('location: login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>KSE</title>
    <link href="assets/img/logo/rancakodee.png" rel="icon">
    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="assets/css/ruang-admin.min.css" rel="stylesheet">

    <style>
        body {
            background-color: var(--bg-color, #ffffff);
            transition: background-color 0.3s, color 0.3s;
        }

        .navbar-brand {
            font-weight: bold;
            color: white !important;
            text-transform: uppercase;
        }

        .navbar-nav .nav-item .nav-link {
            font-size: 1rem;
            font-weight: 500;
        }

        .dropdown-menu {
            border-radius: 0.5rem;
            padding: 0.5rem;
        }

        #darkmodeToggle {
            background-color: var(--btn-bg, #4e73df);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        #darkmodeToggle:hover {
            background-color: var(--btn-hover, #2e59d9);
        }

        /* Title in the topbar */
        .topbar-title {
            font-size: 18px;
            font-weight: bold;
            color: white;
            text-transform: uppercase;
            margin-right: auto;
            text-align: center;
        }
    </style>
</head>

<body data-bs-theme= "dark" id="page-top">
<div class="form-check form-switch mx-4">
      <input
        class="form-check-input p-2"
        type="checkbox"
        role="switch"
        id="flexSwitchCheckChecked"
        checked
        onclick="myFunction()"
      />
      </div>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="?page=home">
                <div class="sidebar-brand-icon">
                    <img src="assets/img/logo/rancakodee.png" alt="Logo">
                </div>
                <div class="sidebar-brand-text mx-3">KSE UNAND</div>
            </a>
            <hr class="sidebar-divider my-0">
            <li class="nav-item">
                <a class="nav-link" href="?page=home">
                    <i class="fas fa-home"></i>
                    <span>Beranda</span>
                </a>
            </li>
            <hr class="sidebar-divider">
            <div class="sidebar-heading">Perhitungan</div>
            <?php $query = $connection->query("SELECT * FROM beasiswa");
            while ($row = $query->fetch_assoc()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="?page=perhitungan&beasiswa=<?= $row["kd_beasiswa"] ?>">
                        <i class="fas fa-calculator"></i>
                        <span><?= $row["nama"] ?></span>
                    </a>
                </li>
            <?php endwhile; ?>
            <hr class="sidebar-divider">
            <div class="sidebar-heading">Input</div>
            <li class="nav-item">
                <a class="nav-link" href="?page=beasiswa">
                    <i class="fas fa-database"></i>
                    <span>Data Beasiswa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?page=mahasiswa">
                    <i class="fas fa-user-graduate"></i>
                    <span>Data Mahasiswa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?page=kriteria">
                    <i class="fas fa-list"></i>
                    <span>Kriteria</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?page=model">
                    <i class="fas fa-cogs"></i>
                    <span>Model</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?page=penilaian">
                    <i class="fas fa-clipboard-check"></i>
                    <span>Penilaian</span>
                </a>
            </li>
            <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="?page=nilai">
                    <i class="fas fa-clipboard-check"></i>
                    <span>Input nilai mahasiswa</span>
                </a>
            </li>
            <hr class="sidebar-divider">
            <div class="sidebar-heading">Laporan</div>
            <li class="nav-item">
                <a class="nav-link" href="?page=lap_seluruh">
                    <i class="fas fa-file-alt"></i>
                    <span>Seluruh Mahasiswa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?page=lap_permahasiswa">
                    <i class="fas fa-user"></i>
                    <span>Per Mahasiswa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?page=lap_pendaftaran">
                    <i class="fas fa-file-signature"></i>
                    <span>Pendaftaran</span>
                </a>
            </li>
            <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
                    <button id="sidebarToggleTop" class="btn btn-link rounded-circle">
                        <i class="fa fa-bars"></i>
                    </button>
                    <!-- Title added here -->
                    <div class="topbar-title">Sistem Penilaian Penerimaan Beasiswa Karya Salemba Empat Universitas Andalas</div>
                    <ul class="navbar-nav ml-auto">
                    <!-- Profil Dropdown -->
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="ml-2 d-none d-lg-inline text-white small"><?= ucfirst($_SESSION["username"]); ?></span>
                            <hr class="topbar-divider">
                            <img class="img-profile rounded-circle" >
                        </a>
                        <!-- Dropdown Menu -->
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                            <a class="dropdown-item" href="?page=profile">
                                <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                Profil Saya
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="logout.php">
                                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                Logout
                            </a>
                        </div>
                    </li>
                    <!-- Dark Mode Button -->
                    <button id="darkmodeToggle">Dark Mode</button>
                </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <?php include page($_PAGE); ?>
                </div>
                <!-- End of Main Content -->

            </div>
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scripts -->
    <script>
      function myFunction() {
        var element = document.body;
        element.dataset.bsTheme =
          element.dataset.bsTheme == "light" ? "dark" : "light";
      }
      function stepFunction(event) {
        debugger;
        var element = document.getElementsByClassName("collapse");
        for (var i = 0; i < element.length; i++) {
          if (element[i] !== event.target.ariaControls) {
            element[i].classList.remove("show");
          }
        }
      }
    </script>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="assets/js/ruang-admin.min.js"></script>
    <script>
 // Dark Mode Toggle
 const darkModeToggle = document.getElementById('darkmodeToggle');
        const content = document.getElementById('content');
        

        darkModeToggle.addEventListener('click', () => {
            content.classList.toggle('bg-dark');
        });
    </script>
</body>

</html>
