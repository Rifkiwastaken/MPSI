<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once "config.php";
    $sql = "SELECT * FROM pengguna WHERE username='$_POST[username]' AND password='" . md5($_POST['password']) . "'";
    if ($query = $connection->query($sql)) {
        if ($query->num_rows) {
            session_start();
            while ($data = $query->fetch_array()) {
                $_SESSION["is_logged"] = true;
                $_SESSION["as"] = $data["status"];
                $_SESSION["username"] = $data["username"];
            }
            header('location: index.php');
        } else {
            echo "<script>alert('Username atau Password tidak sesuai!');</script>";
        }
    } else {
        echo "Query error!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beasiswa - Login</title>
    <link href="assets/img/logo/rancakodee.png" rel="icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
            margin: 0;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            border-radius: 10px;
            background: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .login-container h3 {
            margin-bottom: 20px;
            text-align: center;
            color: #17a2b8;
        }

        .btn-register {
            background-color: #28a745;
            color: white;
            margin-top: 10px;
        }

        .btn-register:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h3>LOGIN</h3>
        <form action="<?= $_SERVER['REQUEST_URI'] ?>" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" class="form-control" id="username" placeholder="Username" autofocus required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
            </div>
            <button type="submit" class="btn btn-info btn-block">Login</button>
            <!-- <a href="register.php" class="btn btn-register btn-block">Register</a> -->
        </form>
    </div>
</body>

</html>
