<?php
$update = (isset($_GET['action']) AND $_GET['action'] == 'update') ? true : false;
if ($update) {
	$sql = $connection->query("SELECT * FROM beasiswa WHERE kd_beasiswa='$_GET[key]'");
	$row = $sql->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$validasi = false; $err = false;
	if ($update) {
		$sql = "UPDATE beasiswa SET nama='$_POST[nama]' WHERE kd_beasiswa='$_GET[key]'";
	} else {
		$sql = "INSERT INTO beasiswa VALUES (NULL, '$_POST[nama]')";
		$validasi = true;
	}

	if ($validasi) {
		$q = $connection->query("SELECT kd_beasiswa FROM beasiswa WHERE nama LIKE '%$_POST[nama]%'");
		if ($q->num_rows) {
			echo alert("Beasiswa sudah ada!", "?page=beasiswa");
			$err = true;
		}
	}

  if (!$err AND $connection->query($sql)) {
    echo alert("Berhasil!", "?page=beasiswa");
  } else {
		echo alert("Gagal!", "?page=beasiswa");
  }
}

if (isset($_GET['action']) AND $_GET['action'] == 'delete') {
  $connection->query("DELETE FROM beasiswa WHERE kd_beasiswa='$_GET[key]'");
	echo alert("Berhasil!", "?page=beasiswa");
}
?>
<div class="row">
	<div class="col-md-4">
	    <div class="panel" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
	        <div class="panel-heading" style="background-color: #FF9800; color: #fff; padding: 15px; border-top-left-radius: 8px; border-top-right-radius: 8px;">
                <h3 class="text-center"><?= ($update) ? "EDIT" : "TAMBAH" ?></h3>
            </div>
	        <div class="panel-body" style="padding: 20px;">
	            <form action="<?=$_SERVER['REQUEST_URI']?>" method="POST">
	                <div class="form-group">
	                    <label for="nama">Nama Beasiswa</label>
	                    <input type="text" name="nama" class="form-control" <?= (!$update) ?: 'value="'.$row["nama"].'"' ?>>
	                </div>
	                <button type="submit" class="btn" style="background-color: #FF9800; color: #fff; width: 100%; padding: 10px; border: none; border-radius: 5px;">
                        Simpan
                    </button>
	                <?php if ($update): ?>
						<a href="?page=beasiswa" class="btn btn-info" style="margin-top: 10px; width: 100%; padding: 10px; text-align: center; background-color: #0288d1; color: #fff; border-radius: 5px;">Batal</a>
					<?php endif; ?>
	            </form>
	        </div>
	    </div>
	</div>
	<div class="col-md-8">
	    <div class="panel" style="background-color: #fff; border-radius: 8px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
	        <div class="panel-heading" style="background-color: #0288d1; color: #fff; padding: 15px; border-top-left-radius: 8px; border-top-right-radius: 8px;">
                <h3 class="text-center">DAFTAR BEASISWA</h3>
            </div>
	        <div class="panel-body" style="padding: 20px;">
	            <table class="table table-condensed" style="width: 100%; border-collapse: collapse; margin-bottom: 20px; text-align: center;">
	                <thead>
	                    <tr>
	                        <th>No</th>
	                        <th>Nama</th>
	                        <th>Aksi</th>
	                    </tr>
	                </thead>
	                <tbody>
	                    <?php $no = 1; ?>
	                    <?php if ($query = $connection->query("SELECT * FROM beasiswa")): ?>
	                        <?php while($row = $query->fetch_assoc()): ?>
	                        <tr>
	                            <td><?=$no++?></td>
	                            <td><?=$row['nama']?></td>
	                            <td>
	                                <div class="btn-group">
	                                    <a href="?page=beasiswa&action=update&key=<?=$row['kd_beasiswa']?>" class="btn" style="background-color: #FF9800; color: #fff; padding: 5px 10px; text-decoration: none; border-radius: 5px; margin-right: 5px;">Edit</a>
	                                    <a href="?page=beasiswa&action=delete&key=<?=$row['kd_beasiswa']?>" class="btn" style="background-color: #d32f2f; color: #fff; padding: 5px 10px; text-decoration: none; border-radius: 5px;">Hapus</a>
	                                </div>
	                            </td>
	                        </tr>
	                        <?php endwhile ?>
	                    <?php endif ?>
	                </tbody>
	            </table>
	        </div>
	    </div>
	</div>
</div>
