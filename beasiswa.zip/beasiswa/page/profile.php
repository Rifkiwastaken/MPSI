<?php
// Ambil data pengguna dari sesi
$username = $_SESSION["username"];

// Proses form jika ada data yang dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $error = [];
    $success = "";

    // Proses update foto profil
    if (isset($_FILES["profile_picture"]) && $_FILES["profile_picture"]["error"] == 0) {
        $target_dir = "assets/img/profile/";
        $target_file = $target_dir . basename($_FILES["profile_picture"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (in_array($imageFileType, ["jpg", "jpeg", "png"])) {
            if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                $query = "UPDATE users SET profile_picture = '$target_file' WHERE username = '$username'";
                if ($connection->query($query)) {
                    $_SESSION["profile_picture"] = $target_file;
                    $success = "Foto profil berhasil diperbarui.";
                } else {
                    $error[] = "Gagal memperbarui foto profil di database.";
                }
            } else {
                $error[] = "Gagal mengupload file.";
            }
        } else {
            $error[] = "Tipe file tidak valid. Harus JPG, JPEG, atau PNG.";
        }
    }

    // Proses update username
    if (!empty($_POST["new_username"])) {
        $new_username = $connection->real_escape_string($_POST["new_username"]);
        $query = "UPDATE users SET username = '$new_username' WHERE username = '$username'";
        if ($connection->query($query)) {
            $_SESSION["username"] = $new_username;
            $username = $new_username;
            $success = "Username berhasil diperbarui.";
        } else {
            $error[] = "Gagal memperbarui username.";
        }
    }

    // Proses update password
    if (!empty($_POST["current_password"]) && !empty($_POST["new_password"])) {
        $current_password = $connection->real_escape_string($_POST["current_password"]);
        $new_password = $connection->real_escape_string(password_hash($_POST["new_password"], PASSWORD_BCRYPT));

        $result = $connection->query("SELECT password FROM users WHERE username = '$username'");
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($current_password, $row["password"])) {
                $query = "UPDATE users SET password = '$new_password' WHERE username = '$username'";
                if ($connection->query($query)) {
                    $success = "Password berhasil diperbarui.";
                } else {
                    $error[] = "Gagal memperbarui password.";
                }
            } else {
                $error[] = "Password lama salah.";
            }
        }
    }
}

// Ambil data profil untuk ditampilkan
$result = $connection->query("SELECT * FROM users WHERE username = '$username'");
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --color-primary: #FF9800; /* Orange */
            --color-white: #e9e9e9;
            --color-black: #141d28;
            --color-black-1: #212b38;
            --bg-light: #fff3e0;
            --text-dark: #bf360c;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
        }

        .container {
            padding: 50px 5%;
        }

        .panel {
            background-color: var(--color-white);
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .panel-heading {
            background-color: var(--color-primary);
            color: var(--color-white);
            padding: 15px 20px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        .panel-heading h2 {
            text-align: center;
            margin: 0;
            font-size: 24px;
        }

        .panel-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .btn {
            background-color: var(--color-primary);
            color: var(--color-white);
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #e68a00;
        }

        .profile-picture {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto;
            display: block;
        }

        .alert {
            background-color: #ffcdd2;
            color: #c62828;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="panel">
            <div class="panel-heading">
                <h2>Profil Saya</h2>
            </div>
            <div class="panel-body">
                <?php if (!empty($error)): ?>
                    <div class="alert">
                        <ul>
                            <?php foreach ($error as $err): ?>
                                <li><?= $err ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert" style="background-color: #c8e6c9; color: #388e3c;"><?= $success ?></div>
                <?php endif; ?>

                <img src="<?= $user["profile_picture"]?>" alt="Foto Profil" class="profile-picture">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="profile_picture">Foto Profil</label>
                        <input type="file" name="profile_picture" id="profile_picture" class="form-control">
                    </div>
                    <button type="submit" class="btn">Perbarui Foto</button>
                </form>

                <hr>

                <form action="" method="POST">
                    <div class="form-group">
                        <label for="new_username">Username</label>
                        <input type="text" name="new_username" id="new_username" class="form-control" value="<?= $user["username"] ?>">
                    </div>
                    <button type="submit" class="btn">Perbarui Username</button>
                </form>

                <hr>

                <form action="" method="POST">
                    <div class="form-group">
                        <label for="current_password">Password Lama</label>
                        <input type="password" name="current_password" id="current_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Password Baru</label>
                        <input type="password" name="new_password" id="new_password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn">Perbarui Password</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
