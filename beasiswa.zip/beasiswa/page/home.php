<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Home</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --color-primary: #0073ff;
            --color-white: #e9e9e9;
            --color-black: #141d28;
            --color-black-1: #212b38;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #fff3e0;
            color: #bf360c;
        }

        .menu-bar {
            background-color: var(--color-black);
            height: 80px;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 5%;
        }

        .menu-bar ul {
            list-style: none;
            display: flex;
        }

        .menu-bar ul li {
            padding: 10px 30px;
            position: relative;
        }

        .menu-bar ul li a {
            font-size: 18px;
            color: var(--color-white);
            text-decoration: none;
            transition: all 0.3s;
        }

        .menu-bar ul li a:hover {
            color: var(--color-primary);
        }

        .menu-bar ul li:hover .dropdown-menu {
            display: block;
            position: absolute;
            left: 0;
            top: 100%;
            background-color: var(--color-black);
        }

        .dropdown-menu {
            display: none;
        }

        .dropdown-menu ul {
            margin: 10px;
        }

        .dropdown-menu ul li {
            width: 150px;
            padding: 10px;
        }

        .dropdown-menu ul li:hover .dropdown-menu-1 {
            display: block;
            position: absolute;
            left: 150px;
            top: 0;
            background-color: var(--color-black);
        }

        .dropdown-menu-1 {
            display: none;
        }
    </style>
</head>
<body>


    <!-- Hero Section -->
    <div class="hero">
        <h1 style="text-align: center; color: #e65100; padding-top: 100px;">
            Selamat Datang di Sistem Pendukung Keputusan <br>
            Penentuan Penerima Beasiswa <br>
            Metode SAW
        </h1>
    </div>

	 <!-- Dashboard Section -->
            <!-- Chart 2 -->
            <div class="chart-box">
                <h3 style="text-align: center;">Bobot Penilaian Kriteria</h3>
                <canvas id="kriteriaChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Chart.js Script -->
    <script>
        // Chart 2: Bobot Penilaian Kriteria
        const ctx2 = document.getElementById('kriteriaChart').getContext('2d');
        new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: ['IPK', 'Ekonomi', 'Prestasi'],
                datasets: [{
                    label: 'Bobot',
                    data: [70, 50, 80],
                    backgroundColor: ['#ff7043', '#ffa726', '#ffd54f']
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>