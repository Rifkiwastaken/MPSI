<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Perhitungan</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --color-primary: #FF9800; /* Orange */
            --color-white: #e9e9e9;
            --color-black: #141d28;
            --color-black-1: #212b38;
            --bg-light: #fff3e0;
            --text-dark: #bf360c;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
        }

        .container {
            padding: 50px 5%;
        }

        .panel {
            background-color: var(--color-white);
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .panel-heading {
            background-color: var(--color-primary);
            color: var(--color-white);
            padding: 15px 20px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        .panel-heading h2 {
            text-align: center;
            margin: 0;
            font-size: 24px;
        }

        .panel-body {
            padding: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            text-align: center; /* Center text */
        }

        .table th, .table td {
            text-align: center; /* Center content in the table */
            padding: 12px 15px;
            border: 1px solid #ddd;
        }

        .table th {
            background-color: var(--color-primary);
            color: var(--color-white);
            font-weight: bold;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .table tbody tr:hover {
            background-color: var(--color-primary);
            color: var(--color-white);
        }

        .alert {
            background-color: #ffcdd2;
            color: #c62828;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if (isset($_GET["beasiswa"])) {
                    $sqlKriteria = "";
                    $namaKriteria = [];
                    $queryKriteria = $connection->query("SELECT a.kd_kriteria, a.nama FROM kriteria a JOIN model b USING(kd_kriteria) WHERE b.kd_beasiswa=$_GET[beasiswa]");
                    while ($kr = $queryKriteria->fetch_assoc()) {
                        $sqlKriteria .= "SUM(
                            IF(
                                c.kd_kriteria=".$kr["kd_kriteria"].",
                                IF(c.sifat='max', nilai.nilai/c.normalization, c.normalization/nilai.nilai), 0
                            )
                        ) AS ".strtolower(str_replace(" ", "_", $kr["nama"])).",";
                        $namaKriteria[] = strtolower(str_replace(" ", "_", $kr["nama"]));
                    }
                    $sql = "SELECT
                        (SELECT nama FROM mahasiswa WHERE nim=mhs.nim) AS nama,
                        (SELECT nim FROM mahasiswa WHERE nim=mhs.nim) AS nim,
                        (SELECT tahun_mengajukan FROM mahasiswa WHERE nim=mhs.nim) AS tahun,
                        $sqlKriteria
                        SUM(
                            IF(
                                    c.sifat = 'max',
                                    nilai.nilai / c.normalization,
                                    c.normalization / nilai.nilai
                            ) * c.bobot
                        ) AS rangking
                    FROM
                        nilai
                        JOIN mahasiswa mhs USING(nim)
                        JOIN (
                            SELECT
                                    nilai.kd_kriteria AS kd_kriteria,
                                    kriteria.sifat AS sifat,
                                    (
                                        SELECT bobot FROM model WHERE kd_kriteria=kriteria.kd_kriteria AND kd_beasiswa=beasiswa.kd_beasiswa
                                    ) AS bobot,
                                    ROUND(
                                        IF(kriteria.sifat='max', MAX(nilai.nilai), MIN(nilai.nilai)), 1
                                    ) AS normalization
                                FROM nilai
                                JOIN kriteria USING(kd_kriteria)
                                JOIN beasiswa ON kriteria.kd_beasiswa=beasiswa.kd_beasiswa
                                WHERE beasiswa.kd_beasiswa=$_GET[beasiswa]
                            GROUP BY nilai.kd_kriteria
                        ) c USING(kd_kriteria)
                    WHERE kd_beasiswa=$_GET[beasiswa]
                    GROUP BY nilai.nim
                    ORDER BY rangking DESC"; ?>
                <div class="panel">
                    <div class="panel-heading">
                        <h2><?php $query = $connection->query("SELECT * FROM beasiswa WHERE kd_beasiswa=$_GET[beasiswa]"); echo $query->fetch_assoc()["nama"]; ?></h2>
                    </div>
                    <div class="panel-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>NIM</th>
                                    <th>Nama</th>
                                    <th>Nilai</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $query = $connection->query($sql); while($row = $query->fetch_assoc()): ?>
                                <?php
                                $rangking = number_format((float) $row["rangking"], 8, '.', '');
                                $q = $connection->query("SELECT nim FROM hasil WHERE nim='$row[nim]' AND kd_beasiswa='$_GET[beasiswa]' AND tahun='$row[tahun]'");
                                if (!$q->num_rows) {
                                $connection->query("INSERT INTO hasil VALUES(NULL, '$_GET[beasiswa]', '$row[nim]', '".$rangking."', '$row[tahun]')");
                                }
                                ?>
                                <tr>
                                    <td><?=$row["nim"]?></td>
                                    <td><?=$row["nama"]?></td>
                                    <td><?=$rangking?></td>
                                </tr>
                                <?php endwhile;?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php } else { ?>
                    <div class="alert">
                        <strong>Perhatian:</strong> Beasiswa belum dipilih. Silakan pilih beasiswa terlebih dahulu.
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</body>
</html>
