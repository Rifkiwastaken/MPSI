<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once "config.php";

    // Validasi input
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    if ($password !== $confirm_password) {
        echo alert("Password dan Konfirmasi Password tidak cocok!", "register.php");
    } else {
        // Cek apakah username sudah ada
        $check_sql = "SELECT * FROM pengguna WHERE username='$username'";
        $check_query = $connection->query($check_sql);
        if ($check_query->num_rows > 0) {
            echo alert("Username sudah digunakan!", "register.php");
        } else {
            // Simpan ke database
            $hashed_password = md5($password);
            $insert_sql = "INSERT INTO pengguna (username, password, status) VALUES ('$username', '$hashed_password', 'user')";
            if ($connection->query($insert_sql)) {
                echo alert("Registrasi berhasil, silakan login!", "login.php");
            } else {
                echo "Query error!";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beasiswa</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
        body {
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-4">
                <div class="panel panel-info">
                    <div class="panel-heading"><h3 class="text-center">REGISTER</h3></div>
                    <div class="panel-body">
                        <form action="<?=$_SERVER['REQUEST_URI']?>" method="POST">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" name="username" class="form-control" id="username" placeholder="Username" required autofocus>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm Password</label>
                                <input type="password" name="confirm_password" class="form-control" id="confirm_password" placeholder="Confirm Password" required>
                            </div>
                            <button type="submit" class="btn btn-info btn-block">Register</button>
                        </form>
                        <div class="form-group text-center mt-3">
                            <p>Sudah punya akun? <a href="login.php" class="text-info">Login di sini</a></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4"></div>
        </div>
    </div>
</body>
</html>
